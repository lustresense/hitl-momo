#!/usr/bin/env bash
# Train the model inside a GPU Docker container (no sudo, venv or tmux needed).
# The container runs in the background, so it keeps going after SSH disconnects.
#
#   bash train/train_in_docker.sh          # start (download, preprocess, MobileNetV2)
#   docker logs -f hitl-train              # follow progress (Ctrl+C only stops watching)
#   docker stop hitl-train                 # cancel
#
# TRAIN_SCRIPTS="train/03_train_custom_cnn.py ..." runs those scripts instead of
# 06_train_mobilenetv2.py, one after another (see train/train_all_models.sh).
#
# Reuses the backend image (already has TensorFlow 2.21) and adds only the NVIDIA
# CUDA pip libraries (~3 GB, kept in .train-home/ so they install once). The
# official tensorflow:*-gpu image is ~8 GB, too big for a small server disk.
set -euo pipefail
cd "$(dirname "$0")/.."

IMAGE="${TRAIN_IMAGE:-hitl-backend}"

docker rm -f hitl-train >/dev/null 2>&1 || true
docker run -d --name hitl-train --gpus all --no-healthcheck \
  --user "$(id -u):$(id -g)" \
  -e HOME=/work/.train-home -e PYTHONPATH=/work -e PYTHONUNBUFFERED=1 \
  -e NVIDIA_DRIVER_CAPABILITIES=compute,utility \
  -e TRAIN_SCRIPTS="${TRAIN_SCRIPTS:-train/06_train_mobilenetv2.py}" \
  -e AFTER_SCRIPT="${AFTER_SCRIPT:-}" \
  -v "$PWD":/work -w /work \
  --entrypoint bash \
  "$IMAGE" -c '
    set -e
    mkdir -p "$HOME"
    pip install --no-cache-dir --user --quiet "tensorflow[and-cuda]==2.21.0" scikit-learn matplotlib
    # TensorFlow does not look in the user site for the pip CUDA libs: point the loader at them.
    export LD_LIBRARY_PATH="$(python -c "import glob, os, site; print(\":\".join(glob.glob(os.path.join(site.getusersitepackages(), \"nvidia\", \"*\", \"lib\"))))")${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    # XLA needs libdevice (nvvm/libdevice/libdevice.10.bc) and ptxas from the pip nvcc package.
    NVCC_DIR="$(python -c "import os, site; print(os.path.join(site.getusersitepackages(), \"nvidia\", \"cuda_nvcc\"))")"
    export XLA_FLAGS="--xla_gpu_cuda_data_dir=$NVCC_DIR"
    export PATH="$NVCC_DIR/bin:$PATH"
    ls "$NVCC_DIR/nvvm/libdevice/libdevice.10.bc"
    python -c "import tensorflow as tf; g=tf.config.list_physical_devices(\"GPU\"); print(\"GPU:\", g); assert g, \"GPU tidak terdeteksi\""
    # Skip the download when a previous run already built the raw dataset.
    if [ -f data/quickdraw_raw.npz ]; then echo "Dataset sudah ada, lewati download"; else python train/01_download_dataset.py; fi
    if [ -f data/processed_data.npz ]; then echo "Data hasil preprocess sudah ada, lewati preprocess"; else python train/02_preprocess_data.py; fi
    for script in $TRAIN_SCRIPTS; do
      echo "===== MULAI $script ($(date "+%Y-%m-%d %H:%M"))"
      # One failing model must not stop the rest of the queue.
      python "$script" || echo "===== GAGAL $script"
    done
    if [ -n "$AFTER_SCRIPT" ]; then python "$AFTER_SCRIPT"; fi
    echo "TRAINING SELESAI"
  '
echo "Training berjalan di container hitl-train. Pantau dengan: docker logs -f hitl-train"
